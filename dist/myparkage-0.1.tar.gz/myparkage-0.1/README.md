# mypackage

this is just a background on how the software was created and also provide how to info.

# How to install